import java.util.Scanner;

public class UpperLower {
     int ch;
    void uppercaseAlphabets(){

        // uppercas
        for ( char c = 'A'; c <= 'Z'; ++c)
            System.out.println(" " + c);
        System.out.println("\n ");
    }
    void LowercaseAlphabets(){

        //Lowercase
        for (char c = 'a'; c <= 'z'; ++c)
            System.out.println(" " + c);
        System.out.println("\n");
    }
    public static void main(String [] args) {
        int ch;
        System.out.println(" Uppercase Alpabets ");
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("lowercase Alphabets ");

    }

    }

